package pl.kinga.produkty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProduktyApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProduktyApplication.class, args);
    }
}
