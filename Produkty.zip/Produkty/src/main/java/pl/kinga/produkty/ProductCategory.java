package pl.kinga.produkty;

public enum ProductCategory {
    GROCERIES, HOUSEHOLDS, OTHER
}
